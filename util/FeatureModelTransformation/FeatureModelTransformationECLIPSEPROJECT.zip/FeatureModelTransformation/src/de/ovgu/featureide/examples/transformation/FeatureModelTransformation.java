package de.ovgu.featureide.examples.transformation;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
/* FeatureIDE - A Framework for Feature-Oriented Software Development
 * Copyright (C) 2005-2019  FeatureIDE team, University of Magdeburg, Germany
 *
 * This file is part of FeatureIDE.
 *
 * FeatureIDE is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * FeatureIDE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with FeatureIDE.  If not, see <http://www.gnu.org/licenses/>.
 *
 * See http://featureide.cs.ovgu.de/ for further information.
 */
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.ovgu.featureide.fm.core.base.IFeatureModel;
import de.ovgu.featureide.fm.core.init.FMCoreLibrary;
import de.ovgu.featureide.fm.core.init.LibraryManager;
import de.ovgu.featureide.fm.core.io.IPersistentFormat;
import de.ovgu.featureide.fm.core.io.dimacs.DIMACSFormat;
import de.ovgu.featureide.fm.core.io.manager.FeatureModelManager;
import de.ovgu.featureide.fm.core.io.uvl.UVLFeatureModelFormat;
import de.ovgu.featureide.fm.core.io.sxfm.SXFMFormat;
import de.ovgu.featureide.fm.core.io.velvet.SimpleVelvetFeatureModelFormat;

/**
 * Example used to translate feature models in various formats such as UVL and
 * DIMACS. Adjusted such that it can be used as standalone jar args[0] String
 * path to the xml file args[1] String path to Folder where files should be
 * stored args[i > 1] String for each wanted format
 * 
 * @author Chico Sundermann, Eric Langenbucher
 */
public class FeatureModelTransformation {

	static {
		LibraryManager.registerLibrary(FMCoreLibrary.getInstance());
	}

	public static void main(String[] args) throws IOException {
		String[] outFormats = new String[] { "uvl", "dimacs", "sxfm", "sv" };
		String pathToFile = "model.xml";
		String outPath = "";
		System.out.println(Arrays.toString(args));
		System.out.println("---Feature Model XML Translation---");
		System.out.println("[INFO] Available formats: " + Arrays.toString(outFormats));
		if (args.length >= 2) {
			pathToFile = args[0].trim();
			outPath = args[1].trim();
			int remainingArgs = args.length - 2;

			if (remainingArgs <= 0) {
				System.out.println("[INFO] No target format(s) given. Assuming to translate model to all formats!");
			} else {
				outFormats = new String[remainingArgs];
				for (int i = 2; i < args.length; i++) {
					int index = args.length - 1 - i;
					outFormats[index] = args[i].trim().toLowerCase();
				}
			}
		} else {
			System.err.println("[ERROR] Not enough arguments! Should be at least 2 but found " + args.length);
			System.exit(1);
		}
		System.out.println("[INFO]File path: " + pathToFile + "\nOut path: " + outPath + "\nChoosen format(s): "
				+ Arrays.toString(outFormats));

		final Path path = Paths.get(pathToFile);
		IFeatureModel model = FeatureModelManager.load(path);
		List<IPersistentFormat<IFeatureModel>> formats = new ArrayList<>();
		int returnCode = 0;
		System.out.println("[INFO] Starting Translation...");
		for (String outFormat : outFormats) {
			switch (outFormat) {
			case "uvl":
				formats.add(new UVLFeatureModelFormat());
				break;
			case "dimacs":
				formats.add(new DIMACSFormat());
				break;
			case "sxfm":
				formats.add(new SXFMFormat());
				break;
			case "sv":
				formats.add(new SimpleVelvetFeatureModelFormat());
				break;
			default:
				System.out.println("[WARNING] Unkown file format " + outFormat);
				returnCode = 2;
				break;
			}
		}
		System.out.println("[INFO] Done!");
		Files.createDirectories(Paths.get(outPath));
		String fileSuffixFromInput = path.getFileName().toString();
		// remove .xml from name
		fileSuffixFromInput = fileSuffixFromInput.substring(0, fileSuffixFromInput.length() - 4) + "_";
		for (IPersistentFormat<IFeatureModel> format : formats) {
			saveFeatureModel(model,
					outPath + File.separator + fileSuffixFromInput + format.getName() + "." + format.getSuffix(),
					format);
		}
		System.out.println("[INFO] Format(s) are stored in result" + File.separator + ".");
		System.exit(returnCode);
	}

	public static void saveFeatureModel(IFeatureModel model, String savePath, IPersistentFormat<IFeatureModel> format) {
		FeatureModelManager.save(model, Paths.get(savePath), format);
	}

}
